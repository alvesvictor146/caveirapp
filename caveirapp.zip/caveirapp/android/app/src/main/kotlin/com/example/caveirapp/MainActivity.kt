package com.example.caveirapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
