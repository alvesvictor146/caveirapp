import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart';
import 'package:intl/intl.dart';



class LocalPage extends StatefulWidget {
  const LocalPage({Key? key}) : super(key: key);



  @override
  State<LocalPage> createState() => _LocalPageState();
}

class _LocalPageState extends State<LocalPage> {

  final dropValue = ValueNotifier('');
    final dropOpcoes = [
    'P.E',
    'STATUS XV',
    'PATRULHAMENTO',
    'ATENDIMENTO',
    'APOIO',
    'ABASTECIMENTO'
  ];

  double? latitude;
  double? longitude;
  String? endereco;
  String? observacao;

  static get dir => null;





  @override
  void initState() {
    
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            ValueListenableBuilder(valueListenable: dropValue,
                builder: (BuildContext context, String value, _) {
                  return DropdownButtonFormField<String>(
                    isExpanded: true,
                    hint: const Text ('Escolha a missão'),
                    decoration: InputDecoration(
                      icon: Icon(Icons.map,
                          color: Colors.yellowAccent),
                      filled: true,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)
                      ),
                      fillColor: Colors.yellow,


                    ),
                    value: (value.isEmpty) ? null : value,
                    onChanged: (escolha) =>
                    dropValue.value = escolha.toString(),
                    items: dropOpcoes.map((op) =>
                        DropdownMenuItem(
                          value: op,
                          child: Text(op),
                        ),

                    )
                        .toList(),
                  );
                }),
            SizedBox(height: 10),
            TextFormField(
              decoration: InputDecoration(
                  hintText: 'OBSERVAÇÕES (TALÃO,ABORDADO...)',
                  filled: true,
                  fillColor: Colors.yellow,
                  border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(10)
                  )
              ),
              onChanged: (val) {
                setState(() {
                  observacao = val;
                });
              },),

            SizedBox(height: 10),

            latitude != null ? Text('Latitude: $latitude',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.yellowAccent,
                    fontSize: 15,
                    fontWeight: FontWeight.bold
                )) : Text('Latitude: ',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,
                )),
            longitude != null ? Text('Longitude: $longitude',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,

                )) : Text('Longitude: ',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,

                )),
            endereco != null ? Text('Endereço: $endereco',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,)) : Text('Endereço:',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,)
            ),
            SizedBox(height: 10),
            Text(
                DateFormat('dd/MM/yyyy  kk:mm').format(DateTime.now()),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.yellowAccent,
                  fontSize: 15,)
            ),
            SizedBox(height: 10),

            SizedBox(height: 90),
            TextButton(
              child: Text('CADASTRAR MISSÃO !'),
              style: ButtonStyle(
                  foregroundColor: MaterialStateProperty.all(Colors.black),
                  backgroundColor: MaterialStateProperty.all(
                      Colors.yellowAccent),
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)
                      )
                  )

              ),
              onPressed: () {   pegarPosicao();   },
            ),

          ]


      ),
    );
  }

  pegarPosicao() async {
    Position posicao = await Geolocator.getCurrentPosition();
    setState(() {
      latitude = posicao.latitude;
      longitude = posicao.longitude;
    });
List<Placemark> locais =  await placemarkFromCoordinates(posicao.latitude, posicao.longitude);
if (locais != null){
setState(() {
  endereco = locais[0].toString();
});

}

  }

}


